var express = require('express');
var router = express.Router();
var request = require('request');
var btoa = require('btoa');
var axios = require('axios');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'MAPPINGS' });
});


router.get('/api', (req, res)=>{


  var data = {
    "domain": "mydomain.com",
    "jabberAddress": "sunnyd@xmpp.xyz",
    "externalAddress": "12017780615"
    }
  var url = 'https://cloud.restcomm.com/xmpp/xmppMappings';
  var username = "AC23f1b11bbb99a46436c365cb7bec246e";
  var password = "eef96b9afe3b9ebcbf051d8adf715943";

  request.post( {
    url : url,
    body : data,
    json : true,
    method : 'POST',
    headers: {
      "Authorization": "Basic " + btoa(username + ":" + password),
      "content-type": "application/json",
    }

  } , (err , doc)=>{

    if ( err ){
      res.send( err )
    }else{
      res.send(doc)
    }


  } )


} )


router.get('/api/get' , (req, res)=>{

  var url = 'https://cloud.restcomm.com/xmpp/xmppMappings';
  var username = "AC23f1b11bbb99a46436c365cb7bec246e";
  var password = "eef96b9afe3b9ebcbf051d8adf715943";

  request.get( {
    url : url,
    method : 'GET',
    headers: {
      'Content-Type': 'application/json',
      "Authorization": "Basic " + btoa(username + ":" + password)
    }

  } , (err , doc)=>{

    if ( err ){
      res.send( err )
    }else{
      res.send(doc)
    }

    console.log("Basic " + btoa(username + ":" + password));
  } )


})

module.exports = router;

/*
$.ajax({
    type:"POST",
    url: proxy + url,
    dataType: 'json',
  headers: {
    "Authorization": "Basic " + btoa(username + ":" + password)
  },
    data:{
    
    "jabberAddress": "sunnyd@xmpp.xyz",
    "externalAddress": "12017780615"

    
    },
    success: function(json) {
        alert("Success", json);
    },
    error: function(XMLHttpRequest, textStatus, errorThrown) {
       alert(textStatus, errorThrown);
    }
*/